import { useState } from 'react'
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { Car, CheckCircle, Camera, FileText, Users, BarChart3, Shield, Clock, Download } from 'lucide-react'
import SignaturePad from './components/SignaturePad.jsx'
import { downloadPDF } from './utils/pdfGenerator.js'
import logo from './assets/logo.png'
import './App.css'

// Componente de Login
function LoginPage({ onLogin }) {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')

  const handleLogin = (e) => {
    e.preventDefault()
    if (email && password) {
      onLogin({ email, role: 'atendente' })
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-blue-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <img src={logo} alt="CheckCar Pro" className="w-24 h-24 mx-auto mb-4" />
          <CardTitle className="text-2xl font-bold text-blue-600">CheckCar Pro</CardTitle>
          <CardDescription>Sistema de Checklist para Lava Rápido</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="seu@email.com"
                required
              />
            </div>
            <div>
              <Label htmlFor="password">Senha</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
              />
            </div>
            <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700">
              Entrar
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}

// Componente de Dashboard
function Dashboard({ user, onLogout }) {
  const [activeTab, setActiveTab] = useState('novo-checklist')
  const [vehicle, setVehicle] = useState({
    plate: '',
    model: '',
    brand: '',
    color: '',
    client: '',
    observations: ''
  })
  
  const [checklist, setChecklist] = useState([
    { id: 1, item: 'Arranhões na carroceria', status: 'sem-danos', observations: '', photos: [] },
    { id: 2, item: 'Amassados', status: 'sem-danos', observations: '', photos: [] },
    { id: 3, item: 'Estado dos pneus', status: 'sem-danos', observations: '', photos: [] },
    { id: 4, item: 'Vidros', status: 'sem-danos', observations: '', photos: [] },
    { id: 5, item: 'Lanternas', status: 'sem-danos', observations: '', photos: [] },
    { id: 6, item: 'Interior do veículo', status: 'sem-danos', observations: '', photos: [] },
    { id: 7, item: 'Objetos no interior', status: 'sem-danos', observations: '', photos: [] }
  ])

  const [signature, setSignature] = useState('')
  const [reports, setReports] = useState([
    { id: 1, plate: 'ABC-1234', client: 'João Silva', date: '2024-01-15', status: 'Concluído', attendant: 'Maria' },
    { id: 2, plate: 'XYZ-5678', client: 'Ana Costa', date: '2024-01-14', status: 'Em andamento', attendant: 'Pedro' },
    { id: 3, plate: 'DEF-9012', client: 'Carlos Santos', date: '2024-01-13', status: 'Concluído', attendant: 'Maria' }
  ])

  const updateChecklistItem = (id, field, value) => {
    setChecklist(prev => prev.map(item => 
      item.id === id ? { ...item, [field]: value } : item
    ))
  }

  const getStatusColor = (status) => {
    switch (status) {
      case 'sem-danos': return 'bg-green-100 text-green-800'
      case 'com-danos': return 'bg-red-100 text-red-800'
      case 'precisa-revisao': return 'bg-yellow-100 text-yellow-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const generateReport = async () => {
    if (!vehicle.plate || !vehicle.client) {
      alert('Por favor, preencha pelo menos a placa e o nome do cliente.')
      return
    }

    const newReport = {
      id: reports.length + 1,
      plate: vehicle.plate,
      client: vehicle.client,
      date: new Date().toISOString().split('T')[0],
      status: 'Concluído',
      attendant: user.email.split('@')[0]
    }
    setReports(prev => [newReport, ...prev])
    
    // Generate PDF
    try {
      await downloadPDF(vehicle, checklist, signature)
    } catch (error) {
      console.error('Erro ao gerar PDF:', error)
    }
    
    // Reset form
    setVehicle({
      plate: '',
      model: '',
      brand: '',
      color: '',
      client: '',
      observations: ''
    })
    setChecklist(prev => prev.map(item => ({
      ...item,
      status: 'sem-danos',
      observations: '',
      photos: []
    })))
    setSignature('')
    
    alert('Relatório gerado e PDF baixado com sucesso!')
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <img src={logo} alt="CheckCar Pro" className="w-10 h-10 mr-3" />
              <h1 className="text-xl font-bold text-blue-600">CheckCar Pro</h1>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">Olá, {user.email}</span>
              <Button variant="outline" onClick={onLogout}>Sair</Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="novo-checklist">Novo Checklist</TabsTrigger>
            <TabsTrigger value="historico">Histórico</TabsTrigger>
            <TabsTrigger value="relatorios">Relatórios</TabsTrigger>
          </TabsList>

          {/* Novo Checklist */}
          <TabsContent value="novo-checklist" className="space-y-6">
            {/* Cadastro do Veículo */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Car className="w-5 h-5 mr-2" />
                  Cadastro do Veículo
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="plate">Placa</Label>
                    <Input
                      id="plate"
                      value={vehicle.plate}
                      onChange={(e) => setVehicle(prev => ({ ...prev, plate: e.target.value }))}
                      placeholder="ABC-1234"
                    />
                  </div>
                  <div>
                    <Label htmlFor="model">Modelo</Label>
                    <Input
                      id="model"
                      value={vehicle.model}
                      onChange={(e) => setVehicle(prev => ({ ...prev, model: e.target.value }))}
                      placeholder="Civic"
                    />
                  </div>
                  <div>
                    <Label htmlFor="brand">Marca</Label>
                    <Input
                      id="brand"
                      value={vehicle.brand}
                      onChange={(e) => setVehicle(prev => ({ ...prev, brand: e.target.value }))}
                      placeholder="Honda"
                    />
                  </div>
                  <div>
                    <Label htmlFor="color">Cor</Label>
                    <Input
                      id="color"
                      value={vehicle.color}
                      onChange={(e) => setVehicle(prev => ({ ...prev, color: e.target.value }))}
                      placeholder="Branco"
                    />
                  </div>
                  <div>
                    <Label htmlFor="client">Nome do Cliente</Label>
                    <Input
                      id="client"
                      value={vehicle.client}
                      onChange={(e) => setVehicle(prev => ({ ...prev, client: e.target.value }))}
                      placeholder="João Silva"
                    />
                  </div>
                </div>
                <div className="mt-4">
                  <Label htmlFor="observations">Observações</Label>
                  <Textarea
                    id="observations"
                    value={vehicle.observations}
                    onChange={(e) => setVehicle(prev => ({ ...prev, observations: e.target.value }))}
                    placeholder="Observações gerais sobre o veículo..."
                  />
                </div>
              </CardContent>
            </Card>

            {/* Checklist */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <CheckCircle className="w-5 h-5 mr-2" />
                  Checklist de Vistoria
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {checklist.map((item) => (
                    <div key={item.id} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="font-medium">{item.item}</h4>
                        <Badge className={getStatusColor(item.status)}>
                          {item.status === 'sem-danos' && 'Sem Danos'}
                          {item.status === 'com-danos' && 'Com Danos'}
                          {item.status === 'precisa-revisao' && 'Precisa Revisão'}
                        </Badge>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-2 mb-3">
                        <Button
                          variant={item.status === 'sem-danos' ? 'default' : 'outline'}
                          size="sm"
                          onClick={() => updateChecklistItem(item.id, 'status', 'sem-danos')}
                          className="bg-green-600 hover:bg-green-700"
                        >
                          Sem Danos
                        </Button>
                        <Button
                          variant={item.status === 'com-danos' ? 'default' : 'outline'}
                          size="sm"
                          onClick={() => updateChecklistItem(item.id, 'status', 'com-danos')}
                          className="bg-red-600 hover:bg-red-700"
                        >
                          Com Danos
                        </Button>
                        <Button
                          variant={item.status === 'precisa-revisao' ? 'default' : 'outline'}
                          size="sm"
                          onClick={() => updateChecklistItem(item.id, 'status', 'precisa-revisao')}
                          className="bg-yellow-600 hover:bg-yellow-700"
                        >
                          Precisa Revisão
                        </Button>
                      </div>

                      <div className="space-y-2">
                        <Textarea
                          placeholder="Observações sobre este item..."
                          value={item.observations}
                          onChange={(e) => updateChecklistItem(item.id, 'observations', e.target.value)}
                          className="text-sm"
                        />
                        <Button variant="outline" size="sm" className="w-full">
                          <Camera className="w-4 h-4 mr-2" />
                          Anexar Fotos
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Assinatura */}
            <SignaturePad 
              onSave={(dataURL) => setSignature(dataURL)}
              onClear={() => setSignature('')}
            />

            {/* Gerar Relatório */}
            <div className="flex justify-end">
              <Button 
                onClick={generateReport}
                className="bg-blue-600 hover:bg-blue-700"
                disabled={!vehicle.plate || !vehicle.client}
              >
                <Download className="w-4 h-4 mr-2" />
                Gerar Relatório PDF
              </Button>
            </div>
          </TabsContent>

          {/* Histórico */}
          <TabsContent value="historico">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Clock className="w-5 h-5 mr-2" />
                  Histórico de Atendimentos
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left p-2">Placa</th>
                        <th className="text-left p-2">Cliente</th>
                        <th className="text-left p-2">Data</th>
                        <th className="text-left p-2">Status</th>
                        <th className="text-left p-2">Atendente</th>
                        <th className="text-left p-2">Ações</th>
                      </tr>
                    </thead>
                    <tbody>
                      {reports.map((report) => (
                        <tr key={report.id} className="border-b">
                          <td className="p-2 font-mono">{report.plate}</td>
                          <td className="p-2">{report.client}</td>
                          <td className="p-2">{report.date}</td>
                          <td className="p-2">
                            <Badge variant={report.status === 'Concluído' ? 'default' : 'secondary'}>
                              {report.status}
                            </Badge>
                          </td>
                          <td className="p-2">{report.attendant}</td>
                          <td className="p-2">
                            <Button variant="outline" size="sm">
                              Ver Detalhes
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Relatórios */}
          <TabsContent value="relatorios">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <BarChart3 className="w-8 h-8 text-blue-600" />
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">Total de Atendimentos</p>
                      <p className="text-2xl font-bold">{reports.length}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <CheckCircle className="w-8 h-8 text-green-600" />
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">Concluídos</p>
                      <p className="text-2xl font-bold">{reports.filter(r => r.status === 'Concluído').length}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <Clock className="w-8 h-8 text-yellow-600" />
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">Em Andamento</p>
                      <p className="text-2xl font-bold">{reports.filter(r => r.status === 'Em andamento').length}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <Users className="w-8 h-8 text-purple-600" />
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">Atendentes</p>
                      <p className="text-2xl font-bold">3</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

// Componente principal
function App() {
  const [user, setUser] = useState(null)

  const handleLogin = (userData) => {
    setUser(userData)
  }

  const handleLogout = () => {
    setUser(null)
  }

  return (
    <Router>
      <div className="App">
        {!user ? (
          <LoginPage onLogin={handleLogin} />
        ) : (
          <Dashboard user={user} onLogout={handleLogout} />
        )}
      </div>
    </Router>
  )
}

export default App

