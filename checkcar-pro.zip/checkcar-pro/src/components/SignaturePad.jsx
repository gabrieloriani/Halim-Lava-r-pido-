import React, { useRef, useState } from 'react'
import SignatureCanvas from 'react-signature-canvas'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'

const SignaturePad = ({ onSave, onClear }) => {
  const sigCanvas = useRef({})
  const [isEmpty, setIsEmpty] = useState(true)

  const clear = () => {
    sigCanvas.current.clear()
    setIsEmpty(true)
    if (onClear) onClear()
  }

  const save = () => {
    if (!sigCanvas.current.isEmpty()) {
      const dataURL = sigCanvas.current.getTrimmedCanvas().toDataURL('image/png')
      if (onSave) onSave(dataURL)
      setIsEmpty(false)
    }
  }

  const handleBegin = () => {
    setIsEmpty(false)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Assinatura do Cliente</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="border-2 border-gray-300 rounded-lg p-4">
          <SignatureCanvas
            ref={sigCanvas}
            penColor="black"
            canvasProps={{
              width: 500,
              height: 200,
              className: 'signature-canvas w-full h-48 border rounded'
            }}
            onBegin={handleBegin}
          />
        </div>
        <div className="flex justify-between mt-4">
          <Button variant="outline" onClick={clear}>
            Limpar
          </Button>
          <Button onClick={save} disabled={isEmpty}>
            Salvar Assinatura
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

export default SignaturePad

