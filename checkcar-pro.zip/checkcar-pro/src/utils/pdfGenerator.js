import jsPDF from 'jspdf'
import html2canvas from 'html2canvas'

export const generatePDFReport = async (vehicleData, checklistData, signature) => {
  const pdf = new jsPDF()
  
  // Header
  pdf.setFontSize(20)
  pdf.text('CheckCar Pro - Relatório de Vistoria', 20, 30)
  
  // Vehicle Information
  pdf.setFontSize(14)
  pdf.text('Dados do Veículo:', 20, 50)
  pdf.setFontSize(12)
  pdf.text(`Placa: ${vehicleData.plate}`, 20, 65)
  pdf.text(`Modelo: ${vehicleData.model}`, 20, 75)
  pdf.text(`Marca: ${vehicleData.brand}`, 20, 85)
  pdf.text(`Cor: ${vehicleData.color}`, 20, 95)
  pdf.text(`Cliente: ${vehicleData.client}`, 20, 105)
  
  if (vehicleData.observations) {
    pdf.text('Observações:', 20, 120)
    const splitObservations = pdf.splitTextToSize(vehicleData.observations, 170)
    pdf.text(splitObservations, 20, 130)
  }
  
  // Checklist
  let yPosition = 150
  pdf.setFontSize(14)
  pdf.text('Checklist de Vistoria:', 20, yPosition)
  yPosition += 15
  
  pdf.setFontSize(10)
  checklistData.forEach((item) => {
    if (yPosition > 250) {
      pdf.addPage()
      yPosition = 30
    }
    
    const statusText = item.status === 'sem-danos' ? 'SEM DANOS' : 
                     item.status === 'com-danos' ? 'COM DANOS' : 'PRECISA REVISÃO'
    
    pdf.text(`• ${item.item}: ${statusText}`, 20, yPosition)
    yPosition += 10
    
    if (item.observations) {
      const splitObs = pdf.splitTextToSize(`  Obs: ${item.observations}`, 160)
      pdf.text(splitObs, 25, yPosition)
      yPosition += splitObs.length * 5
    }
    yPosition += 5
  })
  
  // Signature
  if (signature) {
    if (yPosition > 200) {
      pdf.addPage()
      yPosition = 30
    }
    
    pdf.setFontSize(12)
    pdf.text('Assinatura do Cliente:', 20, yPosition + 20)
    
    // Add signature image
    try {
      pdf.addImage(signature, 'PNG', 20, yPosition + 30, 100, 50)
    } catch (error) {
      console.error('Erro ao adicionar assinatura:', error)
    }
  }
  
  // Footer
  const pageCount = pdf.internal.getNumberOfPages()
  for (let i = 1; i <= pageCount; i++) {
    pdf.setPage(i)
    pdf.setFontSize(8)
    pdf.text(`Data: ${new Date().toLocaleDateString('pt-BR')}`, 20, 280)
    pdf.text(`Página ${i} de ${pageCount}`, 150, 280)
  }
  
  return pdf
}

export const downloadPDF = async (vehicleData, checklistData, signature) => {
  try {
    const pdf = await generatePDFReport(vehicleData, checklistData, signature)
    pdf.save(`checklist-${vehicleData.plate}-${new Date().toISOString().split('T')[0]}.pdf`)
  } catch (error) {
    console.error('Erro ao gerar PDF:', error)
    alert('Erro ao gerar PDF. Tente novamente.')
  }
}

